export default async function handler(req, res) {
  const body = await req.json();
  const userInput = body.prompt;

  const response = await fetch("https://api.x.ai/v1/chat/completions", {
    method: "POST",
    headers: {
      "Content-Type": "application/json",
      "Authorization": "Bearer xai-8mpOkik6NyB8ZOwKY0FmjXaz7qPMy4yJzAj1vc84iGJP59bn6vo5cO7RkCTwuHeztnDywQeuYdH0Paj5"
    },
    body: JSON.stringify({
      model: "grok-3-latest",
      stream: false,
      temperature: 0.7,
      messages: [
        { role: "system", content: "Tu es un assistant affirmé, stylisé et utile." },
        { role: "user", content: userInput }
      ]
    })
  });

  const data = await response.json();
  res.status(200).json(data);
}